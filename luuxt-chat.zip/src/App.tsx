import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './components/AuthContext';
import { Sidebar } from './components/Sidebar';
import { ChatWindow } from './components/ChatWindow';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MessageSquare, Github, Chrome, Phone } from 'lucide-react';
import { db, collection, addDoc, serverTimestamp, query, where, onSnapshot, doc, getDoc, updateDoc, deleteDoc } from './lib/firebase';
import { CallOverlay } from './components/CallOverlay';
import { GroupCallOverlay } from './components/GroupCallOverlay';
import { SettingsModal } from './components/SettingsModal';
import { OperationType, RoomCall, Notification, Room } from './types';
import { handleFirestoreError } from './lib/firestore-helpers';
import { sendNotification } from './lib/notifications';
import { Bell, X as CloseIcon } from 'lucide-react';

function AppContent() {
  const { user, profile, loading, signIn } = useAuth();
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);

  useEffect(() => {
    if (!profile?.settings) return;

    // Apply theme
    const theme = profile.settings.appearance.theme;
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');

    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }

    // Apply accent color
    root.style.setProperty('--natural-sage', profile.settings.appearance.accentColor);
    root.style.setProperty('--natural-sage-light', profile.settings.appearance.accentColor + '33'); // 20% opacity
    
    // Apply font size
    const fontSize = profile.settings.appearance.fontSize;
    root.style.setProperty('font-size', fontSize === 'small' ? '14px' : fontSize === 'large' ? '18px' : '16px');

    // Apply bubble style
    root.style.setProperty('--bubble-radius', profile.settings.appearance.bubbleStyle === 'rounded' ? '16px' : '4px');

  }, [profile?.settings]);

  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [activeRoomCallId, setActiveRoomCallId] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [incomingCall, setIncomingCall] = useState<{ id: string, callerName: string } | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    if (!profile) return;

    // Listen for notifications
    const q = query(
      collection(db, 'notifications'),
      where('recipientUid', '==', profile.uid),
      where('read', '==', false)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newNotifications = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Notification[];
      setNotifications(newNotifications);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notifications');
    });

    return unsubscribe;
  }, [profile]);

  useEffect(() => {
    if (!activeRoomId || !profile) return;

    // Listen for active group calls in the current room
    const q = query(
      collection(db, 'room_calls'),
      where('roomId', '==', activeRoomId),
      where('active', '==', true)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty && !activeRoomCallId) {
        setActiveRoomCallId(snapshot.docs[0].id);
      }
    });

    return unsubscribe;
  }, [activeRoomId, profile, activeRoomCallId]);

  useEffect(() => {
    if (!profile) return;

    // Listen for incoming calls
    const q = query(
      collection(db, 'calls'),
      where('receiverUid', '==', profile.uid),
      where('status', '==', 'ringing')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const callDoc = snapshot.docs[0];
      if (callDoc && !activeCallId) {
        const callData = callDoc.data();
        // Fetch caller name
        const callerSnap = await getDoc(doc(db, 'users', callData.callerUid));
        setIncomingCall({ 
          id: callDoc.id, 
          callerName: callerSnap.data()?.displayName || 'Someone' 
        });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'calls');
    });

    return unsubscribe;
  }, [profile, activeCallId]);

  const handleStartCall = async (friendUid: string, type: 'audio' | 'video' = 'video') => {
    if (!profile) return;
    try {
      const docRef = await addDoc(collection(db, 'calls'), {
        callerUid: profile.uid,
        receiverUid: friendUid,
        status: 'ringing',
        type,
        createdAt: serverTimestamp()
      });
      setActiveCallId(docRef.id);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'calls');
    }
  };

  const handleAcceptCall = () => {
    if (incomingCall) {
      setActiveCallId(incomingCall.id);
      setIncomingCall(null);
    }
  };

  const handleRejectCall = async () => {
    if (incomingCall) {
      await updateDoc(doc(db, 'calls', incomingCall.id), { status: 'rejected' });
      setIncomingCall(null);
    }
  };

  const handleStartGroupCall = async (roomId: string, type: 'audio' | 'video' = 'video') => {
    if (!profile) return;
    try {
      const docRef = await addDoc(collection(db, 'room_calls'), {
        roomId,
        active: true,
        startedBy: profile.uid,
        type,
        createdAt: serverTimestamp()
      });
      setActiveRoomCallId(docRef.id);

      // Fetch room to get members
      const roomSnap = await getDoc(doc(db, 'rooms', roomId));
      if (roomSnap.exists()) {
        const roomData = roomSnap.data() as Room;
        const otherMembers = roomData.members.filter(uid => uid !== profile.uid);
        otherMembers.forEach(uid => {
          sendNotification(
            uid,
            'call',
            `${type === 'video' ? 'Video' : 'Audio'} Call Started`,
            `${profile.displayName} started a ${type} call in ${roomData.name}`,
            { roomId, roomCallId: docRef.id }
          );
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'room_calls');
    }
  };

  const handleDismissNotification = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `notifications/${id}`);
    }
  };

  const handleNotificationAction = async (notif: Notification) => {
    await handleDismissNotification(notif.id);
    if (notif.data?.roomId) {
      setActiveRoomId(notif.data.roomId);
    }
    if (notif.type === 'call' && notif.data?.roomCallId) {
      setActiveRoomCallId(notif.data.roomCallId);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-natural-bg">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-natural-sage border-t-transparent rounded-full animate-spin"></div>
          <p className="text-natural-ink-muted font-medium animate-pulse">Initializing Luuxt...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-natural-bg flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-natural-sage rounded-3xl shadow-xl shadow-natural-sage/20 mb-6 transform -rotate-6">
              <MessageSquare className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-black text-natural-ink tracking-tight mb-2">Luuxt Chat</h1>
            <p className="text-natural-ink-muted text-lg">Connect with your team in real-time.</p>
          </div>

          <div className="bg-natural-card rounded-2xl shadow-[0_2px_10px_rgba(0,0,0,0.03)] border border-natural-border p-8">
            <h2 className="text-xl font-bold text-natural-ink mb-6 text-center">Welcome Back</h2>
            
            <button
              onClick={signIn}
              className="w-full flex items-center justify-center gap-3 bg-natural-card border border-natural-border text-natural-ink font-semibold py-3 px-4 rounded-xl hover:bg-natural-bg transition-all active:scale-[0.98] mb-4"
            >
              <Chrome className="w-5 h-5 text-red-500" />
              Continue with Google
            </button>

            <button
              disabled
              className="w-full flex items-center justify-center gap-3 bg-natural-sage text-white font-semibold py-3 px-4 rounded-xl opacity-50 cursor-not-allowed transition-all"
            >
              <Github className="w-5 h-5" />
              Continue with GitHub
            </button>

            <div className="mt-8 pt-6 border-t border-natural-border text-center">
              <p className="text-xs text-natural-ink-light leading-relaxed">
                By continuing, you agree to Luuxt Chat's Terms of Service and Privacy Policy.
              </p>
            </div>
          </div>
          
          <div className="mt-12 flex justify-center gap-8 opacity-40">
            <div className="flex items-center gap-2 grayscale">
              <div className="w-2 h-2 bg-natural-sage rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-natural-ink">System Online</span>
            </div>
            <div className="flex items-center gap-2 grayscale">
              <span className="text-[10px] font-bold uppercase tracking-widest text-natural-ink">v1.0.4 Stable</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-natural-card overflow-hidden">
      <Sidebar 
        activeRoomId={activeRoomId} 
        onSelectRoom={setActiveRoomId} 
        onStartCall={handleStartCall}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadCount={notifications.length}
      />
      
      <main className="flex-1 flex flex-col min-w-0 relative bg-natural-bg">
        {activeRoomId ? (
          <ChatWindow 
            roomId={activeRoomId} 
            onStartGroupCall={handleStartGroupCall}
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-natural-bg/30">
            <div className="w-24 h-24 bg-natural-card rounded-3xl shadow-sm border border-natural-border flex items-center justify-center mb-6">
              <MessageSquare className="w-10 h-10 text-natural-sage opacity-20" />
            </div>
            <h2 className="text-2xl font-bold text-natural-ink mb-2">No Channel Selected</h2>
            <p className="text-natural-ink-muted max-w-sm">
              Select a channel or friend from the sidebar or create a new one to start chatting with your team.
            </p>
          </div>
        )}

        {/* Incoming Call Notification */}
        {incomingCall && (
          <div className="absolute top-6 right-6 z-[110] bg-natural-card rounded-2xl shadow-2xl border border-natural-border p-6 w-80 animate-in slide-in-from-right-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 rounded-full bg-natural-sage flex items-center justify-center text-white">
                <Phone className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <p className="text-xs font-bold text-natural-ink-light uppercase tracking-wider">Incoming Call</p>
                <p className="font-bold text-natural-ink">{incomingCall.callerName}</p>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleRejectCall}
                className="flex-1 py-2.5 bg-red-50 text-red-600 rounded-xl text-sm font-bold hover:bg-red-100 transition-all"
              >
                Decline
              </button>
              <button
                onClick={handleAcceptCall}
                className="flex-1 py-2.5 bg-natural-sage text-white rounded-xl text-sm font-bold hover:opacity-90 transition-all shadow-sm"
              >
                Accept
              </button>
            </div>
          </div>
        )}

        {/* Active Call Overlay */}
        {activeCallId && (
          <CallOverlay 
            callId={activeCallId} 
            onEnd={() => setActiveCallId(null)} 
          />
        )}

        {/* Active Group Call Overlay */}
        {activeRoomCallId && (
          <GroupCallOverlay 
            roomCallId={activeRoomCallId} 
            onEnd={() => setActiveRoomCallId(null)} 
          />
        )}

        {/* Settings Modal */}
        <SettingsModal 
          isOpen={isSettingsOpen} 
          onClose={() => setIsSettingsOpen(false)} 
        />

        {/* Toasts / Notifications */}
        <div className="fixed top-6 right-6 z-[120] flex flex-col gap-3 pointer-events-none">
          {notifications.map(notif => (
            <div 
              key={notif.id}
              className="pointer-events-auto bg-natural-card rounded-2xl shadow-2xl border border-natural-border p-4 w-80 animate-in slide-in-from-right-8 flex items-start gap-3"
            >
              <div className="w-10 h-10 rounded-full bg-natural-sage/10 flex items-center justify-center text-natural-sage flex-shrink-0">
                <Bell className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-natural-ink truncate">{notif.title}</p>
                <p className="text-xs text-natural-ink-muted line-clamp-2">{notif.body}</p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => handleNotificationAction(notif)}
                    className="px-3 py-1.5 bg-natural-sage text-white rounded-lg text-[10px] font-bold hover:opacity-90 transition-all"
                  >
                    View
                  </button>
                  <button
                    onClick={() => handleDismissNotification(notif.id)}
                    className="px-3 py-1.5 bg-natural-bg text-natural-ink-muted rounded-lg text-[10px] font-bold hover:bg-gray-100 transition-all"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
              <button 
                onClick={() => handleDismissNotification(notif.id)}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <CloseIcon className="w-4 h-4 text-natural-ink-light" />
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ErrorBoundary>
  );
}
