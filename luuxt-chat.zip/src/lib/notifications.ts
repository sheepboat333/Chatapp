import { db, collection, addDoc, serverTimestamp } from './firebase';
import { OperationType } from '../types';
import { handleFirestoreError } from './firestore-helpers';

export async function sendNotification(
  recipientUid: string,
  type: 'message' | 'call',
  title: string,
  body: string,
  data?: any
) {
  try {
    await addDoc(collection(db, 'notifications'), {
      recipientUid,
      type,
      title,
      body,
      data: data || {},
      read: false,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'notifications');
  }
}
