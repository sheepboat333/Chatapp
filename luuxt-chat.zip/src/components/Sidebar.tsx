import React, { useState, useEffect } from 'react';
import { db, collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, where, getDoc, doc } from '../lib/firebase';
import { Room, OperationType } from '../types';
import { handleFirestoreError } from '../lib/firestore-helpers';
import { useAuth } from './AuthContext';
import { cn } from '../lib/utils';
import { Hash, Plus, LogOut, MessageSquare, Users, MessageCircle, Phone, Settings, Bell } from 'lucide-react';
import { FriendsList } from './FriendsList';

interface SidebarProps {
  activeRoomId: string | null;
  onSelectRoom: (roomId: string) => void;
  onStartCall: (friendUid: string, type: 'audio' | 'video') => void;
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
}

export function Sidebar({ activeRoomId, onSelectRoom, onStartCall, onOpenSettings, onOpenNotifications, unreadCount }: SidebarProps) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [view, setView] = useState<'channels' | 'friends'>('channels');
  const { profile, logout } = useAuth();

  useEffect(() => {
    if (!profile) return;

    // Query rooms where the user is a member
    const q = query(
      collection(db, 'rooms'), 
      where('members', 'array-contains', profile.uid),
      orderBy('createdAt', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const roomList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Room[];
      setRooms(roomList);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'rooms');
    });

    return unsubscribe;
  }, [profile]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim() || !profile) return;

    try {
      const docRef = await addDoc(collection(db, 'rooms'), {
        name: newRoomName.trim(),
        createdBy: profile.uid,
        createdAt: serverTimestamp(),
        members: [profile.uid],
        type: 'channel'
      });
      setNewRoomName('');
      setIsCreating(false);
      onSelectRoom(docRef.id);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'rooms');
    }
  };

  const handleStartDM = async (friendUid: string) => {
    if (!profile) return;

    // Check if DM already exists
    const existingDM = rooms.find(r => 
      r.type === 'dm' && 
      r.members.includes(friendUid) && 
      r.members.includes(profile.uid)
    );

    if (existingDM) {
      onSelectRoom(existingDM.id);
      setView('channels');
      return;
    }

    try {
      const friendSnap = await getDoc(doc(db, 'users', friendUid));
      const friendData = friendSnap.data();
      
      const docRef = await addDoc(collection(db, 'rooms'), {
        name: friendData?.displayName || 'Direct Message',
        createdBy: profile.uid,
        createdAt: serverTimestamp(),
        members: [profile.uid, friendUid],
        type: 'dm'
      });
      onSelectRoom(docRef.id);
      setView('channels');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'rooms');
    }
  };

  const channels = rooms.filter(r => r.type === 'channel');
  const dms = rooms.filter(r => r.type === 'dm');

  return (
    <div className="w-80 bg-natural-sidebar border-r border-natural-border flex flex-col h-full">
      {/* App Header */}
      <div className="p-6 border-b border-natural-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-natural-sage rounded-lg flex items-center justify-center shadow-sm">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-black text-natural-ink tracking-tight">Luuxt</h1>
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={onOpenNotifications}
            className="p-2 hover:bg-natural-bg rounded-lg transition-colors relative"
          >
            <Bell className="w-5 h-5 text-natural-ink-light" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
            )}
          </button>
          <button 
            onClick={onOpenSettings}
            className="p-2 hover:bg-natural-bg rounded-lg transition-colors"
          >
            <Settings className="w-5 h-5 text-natural-ink-light" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-4 mt-4 mb-2">
        <div className="flex bg-natural-bg/50 p-1 rounded-xl border border-natural-border">
          <button
            onClick={() => setView('channels')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold uppercase tracking-wider transition-all rounded-lg",
              view === 'channels' ? "bg-natural-card text-natural-ink shadow-sm" : "text-natural-ink-light hover:text-natural-ink"
            )}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            Chats
          </button>
          <button
            onClick={() => setView('friends')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold uppercase tracking-wider transition-all rounded-lg",
              view === 'friends' ? "bg-natural-card text-natural-ink shadow-sm" : "text-natural-ink-light hover:text-natural-ink"
            )}
          >
            <Users className="w-3.5 h-3.5" />
            Friends
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {view === 'channels' ? (
          <div className="mt-2">
            <div className="flex items-center justify-between px-6 py-2">
              <span className="text-[11px] font-bold text-natural-ink-light uppercase tracking-wider">Channels</span>
              <button 
                onClick={() => setIsCreating(true)}
                className="p-1 hover:bg-natural-border/50 rounded-full text-natural-ink-muted transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {isCreating && (
              <form onSubmit={handleCreateRoom} className="px-6 py-2">
                <input
                  autoFocus
                  type="text"
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  placeholder="Channel name..."
                  className="w-full px-4 py-2 text-sm bg-natural-card border border-natural-border rounded-lg outline-none focus:border-natural-sage"
                  onBlur={() => !newRoomName && setIsCreating(false)}
                />
              </form>
            )}

            <div className="space-y-0.5">
              {channels.map((room) => (
                <button
                  key={room.id}
                  onClick={() => onSelectRoom(room.id)}
                  className={cn(
                    "w-full flex items-center gap-4 px-6 py-4 transition-all text-left group",
                    activeRoomId === room.id 
                      ? "bg-natural-sage-light border-r-4 border-natural-sage" 
                      : "hover:bg-natural-sage-light/30 border-r-4 border-transparent"
                  )}
                >
                  <div className="w-10 h-10 rounded-xl bg-natural-sage/10 flex-shrink-0 flex items-center justify-center text-natural-sage font-bold group-hover:scale-105 transition-transform">
                    {room.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-natural-ink truncate tracking-tight">{room.name}</div>
                    <div className="text-[10px] font-bold text-natural-ink-light uppercase tracking-widest">#{room.name.toLowerCase()}</div>
                  </div>
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between px-6 py-2 mt-6">
              <span className="text-[11px] font-bold text-natural-ink-light uppercase tracking-wider">Direct Messages</span>
            </div>
            <div className="space-y-0.5">
              {dms.map((room) => (
                <button
                  key={room.id}
                  onClick={() => onSelectRoom(room.id)}
                  className={cn(
                    "w-full flex items-center gap-4 px-6 py-4 transition-all text-left group",
                    activeRoomId === room.id 
                      ? "bg-natural-sage-light border-r-4 border-natural-sage" 
                      : "hover:bg-natural-sage-light/30 border-r-4 border-transparent"
                  )}
                >
                  <div className="relative group-hover:scale-105 transition-transform">
                    <div className="w-10 h-10 rounded-full bg-natural-sage flex-shrink-0 flex items-center justify-center text-white font-bold shadow-sm">
                      {room.name.substring(0, 1).toUpperCase()}
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full shadow-sm"></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-natural-ink truncate tracking-tight">{room.name}</div>
                    <div className="text-[10px] font-bold text-natural-ink-light uppercase tracking-widest">Online</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-4">
            <FriendsList 
              onStartDM={handleStartDM}
              onCallFriend={onStartCall}
            />
          </div>
        )}
      </div>

      <div className="p-6 bg-natural-sidebar border-t border-natural-border">
        <div className="flex items-center gap-4 mb-4">
          <img 
            src={profile?.photoURL || `https://ui-avatars.com/api/?name=${profile?.displayName}`} 
            alt={profile?.displayName}
            className="w-12 h-12 rounded-full border border-natural-border"
            referrerPolicy="no-referrer"
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-natural-ink truncate">{profile?.displayName}</p>
            <p className="text-xs text-natural-ink-muted truncate">{profile?.email}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-natural-sage text-white rounded-full text-sm font-semibold hover:opacity-90 transition-all shadow-sm"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );
}
