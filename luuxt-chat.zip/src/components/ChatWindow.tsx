import React, { useState, useEffect, useRef } from 'react';
import { db, collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc, arrayUnion, where, setDoc, deleteDoc } from '../lib/firebase';
import { Message, Room, OperationType, UserProfile } from '../types';
import { handleFirestoreError } from '../lib/firestore-helpers';
import { useAuth } from './AuthContext';
import { cn } from '../lib/utils';
import { Send, Hash, UserPlus, X, Video, Phone } from 'lucide-react';
import { format } from 'date-fns';
import { sendNotification } from '../lib/notifications';

interface ChatWindowProps {
  roomId: string;
  onStartGroupCall: (roomId: string, type: 'audio' | 'video') => void;
}

export function ChatWindow({ roomId, onStartGroupCall }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [room, setRoom] = useState<Room | null>(null);
  const [onlineCount, setOnlineCount] = useState(0);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteStatus, setInviteStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { profile } = useAuth();
  const scrollRef = useRef<HTMLDivElement>(null);

  const wallpaperClass = profile?.settings?.appearance.wallpaper === 'dots' 
    ? 'bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]' 
    : profile?.settings?.appearance.wallpaper === 'mesh'
    ? 'bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-natural-sage/10 via-natural-bg to-natural-sage/5'
    : profile?.settings?.appearance.wallpaper === 'lines'
    ? 'bg-[linear-gradient(45deg,#e5e7eb_12.5%,transparent_12.5%,transparent_50%,#e5e7eb_50%,##e5e7eb_62.5%,transparent_62.5%,transparent_100%)] [background-size:20px_20px]'
    : 'bg-natural-bg';

  useEffect(() => {
    // Fetch room details
    const fetchRoom = async () => {
      try {
        const roomSnap = await getDoc(doc(db, 'rooms', roomId));
        if (roomSnap.exists()) {
          setRoom({ id: roomSnap.id, ...roomSnap.data() } as Room);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `rooms/${roomId}`);
      }
    };
    fetchRoom();

    // Listen for messages
    const q = query(
      collection(db, 'rooms', roomId, 'messages'),
      orderBy('createdAt', 'asc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messageList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      setMessages(messageList);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `rooms/${roomId}/messages`);
    });

    return unsubscribe;
  }, [roomId]);

  useEffect(() => {
    if (!room?.members || room.members.length === 0) return;

    // Listen to members' online status
    // Firestore 'in' query limit is 30. For larger groups, we'd need a different strategy.
    const q = query(
      collection(db, 'users'),
      where('uid', 'in', room.members.slice(0, 30))
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const now = Date.now();
      const online = snapshot.docs.filter(doc => {
        const data = doc.data() as UserProfile;
        if (!data.lastSeen) return false;
        const lastSeenMillis = data.lastSeen.toMillis();
        // Consider online if seen in the last 2 minutes
        return (now - lastSeenMillis) < 120000;
      }).length;
      setOnlineCount(online);
    }, (error) => {
      console.error('Error listening to member status:', error);
    });

    return unsubscribe;
  }, [room?.members]);

  useEffect(() => {
    if (!profile) return;

    // Listen for typing users
    const q = query(
      collection(db, 'rooms', roomId, 'typing'),
      where('isTyping', '==', true)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const typing = snapshot.docs
        .filter(d => d.id !== profile.uid) // Don't show myself
        .map(d => d.data().displayName);
      setTypingUsers(typing);
    });

    return unsubscribe;
  }, [roomId, profile?.uid]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const isTypingRef = useRef(false);
  const handleTyping = async () => {
    if (!profile || !roomId) return;

    if (!isTypingRef.current) {
      isTypingRef.current = true;
      await setDoc(doc(db, 'rooms', roomId, 'typing', profile.uid), {
        displayName: profile.displayName,
        isTyping: true,
        updatedAt: serverTimestamp()
      }, { merge: true });
    }

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

    typingTimeoutRef.current = setTimeout(async () => {
      await setDoc(doc(db, 'rooms', roomId, 'typing', profile.uid), {
        isTyping: false,
        updatedAt: serverTimestamp()
      }, { merge: true });
      typingTimeoutRef.current = null;
      isTypingRef.current = false;
    }, 3000);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !profile || isSending || !room) return;

    setIsSending(true);
    const text = inputText.trim();
    try {
      // Clear typing status immediately
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = null;
      }
      await setDoc(doc(db, 'rooms', roomId, 'typing', profile.uid), {
        isTyping: false,
        updatedAt: serverTimestamp()
      }, { merge: true });
      isTypingRef.current = false;

      await addDoc(collection(db, 'rooms', roomId, 'messages'), {
        text,
        senderUid: profile.uid,
        senderName: profile.displayName,
        senderPhoto: profile.photoURL,
        createdAt: serverTimestamp(),
        roomId: roomId,
        font: profile.settings?.appearance.chatFont || 'sans',
        glow: profile.settings?.appearance.messageGlow || false,
        color: profile.settings?.appearance.customMessageColor || null
      });
      setInputText('');

      // Send notifications to other members
      const otherMembers = room.members.filter(uid => uid !== profile.uid);
      otherMembers.forEach(uid => {
        sendNotification(
          uid,
          'message',
          `New message in ${room.name}`,
          `${profile.displayName}: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`,
          { roomId }
        );
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `rooms/${roomId}/messages`);
    } finally {
      setIsSending(false);
    }
  };

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim() || !room) return;

    setInviteStatus(null);
    try {
      // 1. Find user UID by email
      const emailMappingRef = doc(db, 'user_emails', inviteEmail.trim().toLowerCase());
      const mappingSnap = await getDoc(emailMappingRef);

      if (!mappingSnap.exists()) {
        setInviteStatus({ type: 'error', message: 'User not found. They must log in to Luuxt Chat first.' });
        return;
      }

      const targetUid = mappingSnap.data().uid;

      // 2. Add UID to room members
      const roomRef = doc(db, 'rooms', roomId);
      await updateDoc(roomRef, {
        members: arrayUnion(targetUid)
      });

      setInviteStatus({ type: 'success', message: `Successfully invited ${inviteEmail}!` });
      setInviteEmail('');
      setTimeout(() => setIsInviteModalOpen(false), 2000);
    } catch (error) {
      setInviteStatus({ type: 'error', message: 'Failed to invite user. Check permissions.' });
      console.error('Invite error:', error);
    }
  };

  if (!room) return (
    <div className="flex-1 flex items-center justify-center bg-natural-bg">
      <div className="animate-pulse text-natural-ink-light">Loading channel...</div>
    </div>
  );

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? 
      `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}` : 
      '90, 107, 93';
  };

  return (
    <div className="flex-1 flex flex-col bg-natural-bg h-full overflow-hidden relative">
      {/* Header */}
      <div className="h-20 border-b border-natural-border px-8 flex items-center justify-between bg-natural-card/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex-1 flex items-center gap-4 min-w-0">
          <div className="relative flex-shrink-0">
            <div className="w-11 h-11 rounded-2xl bg-natural-sage flex-shrink-0 flex items-center justify-center text-white font-bold shadow-sm">
              {room.name.substring(0, 2).toUpperCase()}
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
          </div>
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-natural-ink leading-tight truncate" title={room.name}>{room.name}</h2>
            <div className="flex items-center gap-2">
              <span className={cn(
                "w-1.5 h-1.5 rounded-full",
                onlineCount > 0 ? "bg-green-500 animate-pulse" : "bg-natural-ink-light"
              )}></span>
              <p className="text-[11px] font-bold text-natural-ink-light uppercase tracking-wider flex items-center gap-1 min-w-0">
                <span className="truncate">{room.members.length} members • {onlineCount} online</span>
                {typingUsers.length > 0 && (
                  <span className="text-natural-sage animate-pulse shrink-0 truncate max-w-[120px] sm:max-w-none">
                    • {typingUsers.length === 1 ? `${typingUsers[0]} is typing...` : `${typingUsers.length} people are typing...`}
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
                <div className="flex items-center bg-natural-bg p-1 rounded-xl border border-natural-border mr-2">
                  <button
                    onClick={() => onStartGroupCall(roomId, 'audio')}
                    className="p-2 text-natural-ink-light hover:text-natural-sage hover:bg-natural-card rounded-lg transition-all"
                    title="Start Audio Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onStartGroupCall(roomId, 'video')}
                    className="p-2 text-natural-ink-light hover:text-natural-sage hover:bg-natural-card rounded-lg transition-all"
                    title="Start Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
          
          <button 
            onClick={() => {
              setIsInviteModalOpen(true);
              setInviteStatus(null);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-natural-sage text-white rounded-xl text-xs font-bold hover:opacity-90 transition-all shadow-lg shadow-natural-sage/20"
          >
            <UserPlus className="w-3.5 h-3.5" />
            Invite
          </button>
        </div>
      </div>

      {/* Invite Modal */}
      {isInviteModalOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-natural-card rounded-2xl shadow-2xl border border-natural-border w-full max-w-md p-8 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-natural-ink">Invite to Channel</h3>
              <button onClick={() => setIsInviteModalOpen(false)} className="p-1 hover:bg-natural-bg rounded-full transition-colors">
                <X className="w-5 h-5 text-natural-ink-light" />
              </button>
            </div>
            
            <form onSubmit={handleInvite} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-natural-ink-light uppercase tracking-wider mb-2">User Email</label>
                <input
                  autoFocus
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-4 py-3 bg-natural-bg border border-natural-border rounded-xl text-sm outline-none focus:ring-2 focus:ring-natural-sage/30 transition-all"
                  required
                />
              </div>

              {inviteStatus && (
                <div className={cn(
                  "p-3 rounded-lg text-xs font-medium",
                  inviteStatus.type === 'success' ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                )}>
                  {inviteStatus.message}
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsInviteModalOpen(false)}
                  className="flex-1 px-4 py-3 border border-natural-border rounded-xl text-sm font-semibold text-natural-ink-muted hover:bg-gray-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-natural-sage text-white rounded-xl text-sm font-semibold hover:opacity-90 transition-all shadow-sm"
                >
                  Send Invite
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Messages */}
      <div 
        ref={scrollRef}
        className={cn("flex-1 overflow-y-auto p-8 space-y-5 scroll-smooth", wallpaperClass)}
      >
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8">
            <div className="w-20 h-20 bg-natural-card rounded-3xl flex items-center justify-center mb-6 shadow-sm border border-natural-border transform -rotate-3">
              <Hash className="w-10 h-10 text-natural-sage opacity-40" />
            </div>
            <h3 className="text-2xl font-black text-natural-ink mb-2">Welcome to #{room.name}!</h3>
            <p className="text-natural-ink-muted max-w-xs mx-auto">This is the start of a beautiful conversation. Send a message to get things moving.</p>
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isMe = msg.senderUid === profile?.uid;
            const prevMsg = messages[idx - 1];
            const isSameSender = prevMsg?.senderUid === msg.senderUid;
            
            return (
              <div key={msg.id} className={cn(
                "flex flex-col group", 
                isMe ? "items-end" : "items-start",
                isSameSender ? "mt-1" : "mt-6"
              )}>
                {!isSameSender && !isMe && (
                  <div className="flex items-center gap-2 mb-1.5 ml-1">
                    <img 
                      src={msg.senderPhoto || `https://ui-avatars.com/api/?name=${msg.senderName}`}
                      className="w-5 h-5 rounded-full border border-natural-border"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-[11px] font-bold text-natural-ink-light uppercase tracking-wider">{msg.senderName}</span>
                  </div>
                )}
                <div className="flex items-end gap-2 max-w-[75%]">
                  {isMe && (
                    <span className="text-[10px] text-natural-ink-muted opacity-0 group-hover:opacity-100 transition-opacity mb-1">
                      {msg.createdAt ? format(msg.createdAt.toDate(), 'h:mm a') : ''}
                    </span>
                  )}
                  <div className={cn(
                    "px-4 py-3 text-[15px] leading-relaxed shadow-sm transition-all",
                    isMe 
                      ? "bg-natural-sage text-white" 
                      : "bg-natural-card text-natural-ink border border-natural-border",
                    msg.font === 'mono' && "font-mono",
                    msg.font === 'serif' && "font-serif",
                    msg.font === 'modern' && "font-modern",
                    msg.font === 'playful' && "font-playful",
                    msg.glow && "shadow-[0_0_15px_rgba(var(--glow-color),0.5)]",
                  )}
                  style={{ 
                    borderRadius: 'var(--bubble-radius)',
                    borderTopRightRadius: isMe ? '0' : 'var(--bubble-radius)',
                    borderTopLeftRadius: !isMe ? '0' : 'var(--bubble-radius)',
                    backgroundColor: isMe && msg.color ? msg.color : undefined,
                    '--glow-color': isMe && msg.color ? hexToRgb(msg.color) : '90, 107, 93'
                  } as React.CSSProperties}>
                    {msg.text}
                  </div>
                  {!isMe && (
                    <span className="text-[10px] text-natural-ink-muted opacity-0 group-hover:opacity-100 transition-opacity mb-1">
                      {msg.createdAt ? format(msg.createdAt.toDate(), 'h:mm a') : ''}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input */}
      <div className="p-6 px-8 bg-natural-card border-t border-natural-border">
        <form 
          onSubmit={handleSendMessage}
          className="flex items-center gap-3"
        >
          <div className="flex-1 flex items-center bg-natural-bg rounded-2xl p-1.5 pl-5 border border-natural-border focus-within:border-natural-sage transition-all">
            <input
              type="text"
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                handleTyping();
              }}
              placeholder={`Message #${room.name}`}
              className="flex-1 border-none outline-none py-2 text-[15px] bg-transparent text-natural-ink placeholder:text-natural-ink-muted"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isSending}
              className="bg-natural-sage text-white p-2.5 rounded-xl hover:opacity-90 disabled:opacity-50 transition-all shadow-lg shadow-natural-sage/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
        <p className="mt-2 text-[10px] text-natural-ink-light text-center uppercase tracking-widest font-bold">
          Press Enter to send
        </p>
      </div>
    </div>
  );
}
