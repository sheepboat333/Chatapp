import { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo,
    });
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-natural-bg p-4">
          <div className="max-w-lg w-full bg-white rounded-2xl shadow-xl border border-natural-border p-8">
            <h2 className="text-2xl font-bold text-natural-ink mb-4">Something went wrong</h2>
            <div className="bg-red-50 rounded-xl p-4 mb-6 overflow-auto max-h-64">
              <p className="text-red-600 font-mono text-sm break-words">
                {this.state.error?.toString()}
              </p>
              {this.state.errorInfo && (
                <pre className="mt-4 text-xs text-red-400 font-mono whitespace-pre-wrap">
                  {this.state.errorInfo.componentStack}
                </pre>
              )}
            </div>
            <button
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-natural-sage text-white rounded-xl font-semibold hover:opacity-90 transition-all"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
