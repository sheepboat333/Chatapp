import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { db, doc, updateDoc } from '../lib/firebase';
import { X, User, Bell, Shield, Palette, Save, Loader2, Moon, Sun, Monitor, Type, Check, Camera, Image as ImageIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { UserSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AVATAR_OPTIONS = [
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Milo',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Luna',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Jasper',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Zoe',
];

const WALLPAPERS = [
  { id: 'none', label: 'None', class: 'bg-natural-bg' },
  { id: 'dots', label: 'Dots', class: 'bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]' },
  { id: 'mesh', label: 'Mesh', class: 'bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-natural-sage/10 via-natural-bg to-natural-sage/5' },
  { id: 'lines', label: 'Lines', class: 'bg-[linear-gradient(45deg,#e5e7eb_12.5%,transparent_12.5%,transparent_50%,#e5e7eb_50%,#e5e7eb_62.5%,transparent_62.5%,transparent_100%)] [background-size:20px_20px]' },
];

const ACCENT_COLORS = [
  { id: 'sage', value: '#8C9A8E', label: 'Sage' },
  { id: 'ocean', value: '#3B82F6', label: 'Ocean' },
  { id: 'rose', value: '#EF4444', label: 'Rose' },
  { id: 'amber', value: '#F59E0B', label: 'Amber' },
  { id: 'violet', value: '#8B5CF6', label: 'Violet' },
  { id: 'emerald', value: '#10B981', label: 'Emerald' },
  { id: 'slate', value: '#475569', label: 'Slate' },
];

const FONTS = [
  { id: 'sans', label: 'Inter', class: 'font-sans' },
  { id: 'mono', label: 'JetBrains', class: 'font-mono' },
  { id: 'serif', label: 'Playfair', class: 'font-serif' },
  { id: 'modern', label: 'Grotesk', class: 'font-modern' },
  { id: 'playful', label: 'Comic', class: 'font-playful' },
];

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { profile } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [isChangingPhoto, setIsChangingPhoto] = useState(false);
  const [settings, setSettings] = useState<UserSettings | null>(profile?.settings || null);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'appearance' | 'security'>('profile');

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName);
      setPhotoURL(profile.photoURL || '');
      if (profile.settings) {
        setSettings(profile.settings);
      }
    }
  }, [profile, isOpen]);

  if (!isOpen) return null;

  const handleSave = async (updatedSettings?: Partial<UserSettings>, newPhotoURL?: string) => {
    if (!profile) return;
    setIsSaving(true);
    try {
      const updateData: any = {
        displayName: displayName.trim(),
        photoURL: newPhotoURL || photoURL
      };
      
      if (updatedSettings || settings) {
        updateData.settings = { ...(settings || {}), ...(updatedSettings || {}) };
      }

      await updateDoc(doc(db, 'users', profile.uid), updateData);
      
      if (!updatedSettings) {
        onClose();
      }
    } catch (error) {
      console.error('Error updating settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const updateSetting = (category: keyof UserSettings, key: string, value: any) => {
    if (!settings) return;
    const newSettings = {
      ...settings,
      [category]: {
        ...settings[category],
        [key]: value
      }
    };
    setSettings(newSettings);
    // Auto-save for toggles
    handleSave(newSettings);
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'security', label: 'Security', icon: Shield },
  ] as const;

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-natural-ink/40 backdrop-blur-sm animate-in fade-in duration-300"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-4xl h-[650px] bg-natural-card rounded-3xl shadow-2xl flex overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Sidebar */}
        <div className="w-64 bg-natural-bg border-r border-natural-border p-6 flex flex-col">
          <div className="flex items-center gap-2 mb-8 px-2">
            <div className="w-8 h-8 bg-natural-sage rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-lg font-black text-natural-ink">Settings</h2>
          </div>

          <nav className="flex-1 space-y-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all text-left",
                    activeTab === tab.id 
                      ? "bg-natural-card text-natural-ink shadow-sm border border-natural-border" 
                      : "text-natural-ink-light hover:bg-natural-card/50 hover:text-natural-ink"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          <div className="mt-auto pt-6 border-t border-natural-border">
            <div className="flex items-center gap-3 px-2">
              <img 
                src={profile?.photoURL || `https://ui-avatars.com/api/?name=${profile?.displayName}`}
                className="w-10 h-10 rounded-full border border-natural-border"
                referrerPolicy="no-referrer"
              />
              <div className="min-w-0">
                <p className="text-xs font-bold text-natural-ink truncate">{profile?.displayName}</p>
                <p className="text-[10px] text-natural-ink-muted truncate">v1.0.5 Stable</p>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col bg-natural-card">
          <header className="px-8 py-6 border-b border-natural-border flex items-center justify-between">
            <h3 className="text-xl font-bold text-natural-ink">
              {tabs.find(t => t.id === activeTab)?.label}
            </h3>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-natural-bg rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-natural-ink-light" />
            </button>
          </header>

          <div className="flex-1 overflow-y-auto p-8">
            {activeTab === 'profile' && (
              <div className="max-w-md space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="flex items-center gap-6">
                  <div className="relative group">
                    <img 
                      src={photoURL || `https://ui-avatars.com/api/?name=${displayName}`}
                      className="w-24 h-24 rounded-3xl border-2 border-natural-border shadow-lg object-cover bg-natural-bg"
                      referrerPolicy="no-referrer"
                    />
                    <button 
                      onClick={() => setIsChangingPhoto(!isChangingPhoto)}
                      className="absolute inset-0 bg-black/40 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                    >
                      <Camera className="w-6 h-6 text-white" />
                    </button>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-natural-ink mb-1">Profile Picture</h4>
                    <p className="text-sm text-natural-ink-muted">Choose an avatar or provide a URL.</p>
                  </div>
                </div>

                {isChangingPhoto && (
                  <div className="p-4 bg-natural-bg rounded-2xl border border-natural-border animate-in zoom-in-95 duration-200">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs font-bold text-natural-ink-light uppercase tracking-wider">Choose Avatar</span>
                      <button onClick={() => setIsChangingPhoto(false)} className="text-natural-ink-light hover:text-natural-ink">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-6 gap-2 mb-4">
                      {AVATAR_OPTIONS.map((url, i) => (
                        <button 
                          key={i}
                          onClick={() => {
                            setPhotoURL(url);
                            setIsChangingPhoto(false);
                          }}
                          className={cn(
                            "w-full aspect-square rounded-lg border-2 transition-all hover:scale-105",
                            photoURL === url ? "border-natural-sage" : "border-transparent"
                          )}
                        >
                          <img src={url} className="w-full h-full rounded-md" />
                        </button>
                      ))}
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-natural-ink-light uppercase tracking-widest">Or Custom URL</label>
                      <div className="flex gap-2">
                        <input 
                          type="text"
                          value={photoURL}
                          onChange={(e) => setPhotoURL(e.target.value)}
                          placeholder="https://..."
                          className="flex-1 px-3 py-2 bg-natural-bg border border-natural-border rounded-lg text-xs outline-none focus:border-natural-sage"
                        />
                        <button 
                          onClick={() => setIsChangingPhoto(false)}
                          className="p-2 bg-natural-sage text-white rounded-lg"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-natural-ink-light uppercase tracking-wider mb-2">Display Name</label>
                    <input 
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full px-4 py-3 bg-natural-bg border border-natural-border rounded-xl outline-none focus:border-natural-sage transition-all"
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-natural-ink-light uppercase tracking-wider mb-2">Email Address</label>
                    <input 
                      type="email"
                      value={profile?.email || ''}
                      disabled
                      className="w-full px-4 py-3 bg-natural-bg border border-natural-border rounded-xl opacity-50 cursor-not-allowed"
                    />
                    <p className="mt-2 text-xs text-natural-ink-muted italic">Email cannot be changed as it's linked to your Google account.</p>
                  </div>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => handleSave()}
                    disabled={isSaving || !displayName.trim() || (displayName === profile?.displayName && photoURL === profile?.photoURL)}
                    className="flex items-center gap-2 px-6 py-3 bg-natural-sage text-white rounded-xl font-bold hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-natural-sage/20"
                  >
                    {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Save Changes
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && settings && (
              <div className="max-w-md space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-natural-bg rounded-2xl border border-natural-border">
                    <div>
                      <h4 className="font-bold text-natural-ink">Sound Notifications</h4>
                      <p className="text-xs text-natural-ink-muted">Play a sound when you receive a message.</p>
                    </div>
                    <button 
                      onClick={() => updateSetting('notifications', 'sound', !settings.notifications.sound)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.notifications.sound ? "bg-natural-sage" : "bg-gray-300"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.notifications.sound ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-natural-bg rounded-2xl border border-natural-border">
                    <div>
                      <h4 className="font-bold text-natural-ink">Desktop Notifications</h4>
                      <p className="text-xs text-natural-ink-muted">Show notifications on your desktop.</p>
                    </div>
                    <button 
                      onClick={() => updateSetting('notifications', 'desktop', !settings.notifications.desktop)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.notifications.desktop ? "bg-natural-sage" : "bg-gray-300"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.notifications.desktop ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-natural-bg rounded-2xl border border-natural-border">
                    <div>
                      <h4 className="font-bold text-natural-ink">Mentions Only</h4>
                      <p className="text-xs text-natural-ink-muted">Only notify when you are mentioned.</p>
                    </div>
                    <button 
                      onClick={() => updateSetting('notifications', 'mentionsOnly', !settings.notifications.mentionsOnly)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.notifications.mentionsOnly ? "bg-natural-sage" : "bg-gray-300"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.notifications.mentionsOnly ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'appearance' && settings && (
              <div className="max-w-md space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-300 pb-10">
                {/* Theme & Font Size */}
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Theme</label>
                    <div className="flex bg-natural-bg p-1 rounded-xl border border-natural-border">
                      {(['light', 'dark', 'system'] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => updateSetting('appearance', 'theme', t)}
                          className={cn(
                            "flex-1 flex items-center justify-center py-2 rounded-lg transition-all",
                            settings.appearance.theme === t ? "bg-natural-card text-natural-ink shadow-sm" : "text-natural-ink-light hover:text-natural-ink"
                          )}
                          title={t}
                        >
                          {t === 'light' && <Sun className="w-4 h-4" />}
                          {t === 'dark' && <Moon className="w-4 h-4" />}
                          {t === 'system' && <Monitor className="w-4 h-4" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Font Size</label>
                    <div className="flex bg-natural-bg p-1 rounded-xl border border-natural-border">
                      {(['small', 'medium', 'large'] as const).map((size) => (
                        <button
                          key={size}
                          onClick={() => updateSetting('appearance', 'fontSize', size)}
                          className={cn(
                            "flex-1 flex items-center justify-center py-2 text-[10px] font-black uppercase transition-all rounded-lg",
                            settings.appearance.fontSize === size ? "bg-natural-card text-natural-ink shadow-sm" : "text-natural-ink-light hover:text-natural-ink"
                          )}
                        >
                          {size.charAt(0)}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Accent Color */}
                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Accent Color</label>
                  <div className="flex flex-wrap gap-3">
                    {ACCENT_COLORS.map((color) => (
                      <button
                        key={color.id}
                        onClick={() => updateSetting('appearance', 'accentColor', color.value)}
                        className={cn(
                          "w-10 h-10 rounded-2xl border-2 transition-all flex items-center justify-center shadow-sm",
                          settings.appearance.accentColor === color.value ? "border-natural-ink scale-110" : "border-transparent hover:scale-105"
                        )}
                        style={{ backgroundColor: color.value }}
                        title={color.label}
                      >
                        {settings.appearance.accentColor === color.value && <Check className="w-5 h-5 text-white" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Chat Wallpaper */}
                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Chat Wallpaper</label>
                  <div className="grid grid-cols-4 gap-3">
                    {WALLPAPERS.map((wp) => (
                      <button
                        key={wp.id}
                        onClick={() => updateSetting('appearance', 'wallpaper', wp.id)}
                        className={cn(
                          "h-16 rounded-xl border-2 transition-all overflow-hidden relative",
                          settings.appearance.wallpaper === wp.id ? "border-natural-sage" : "border-natural-border hover:border-natural-ink-light/20"
                        )}
                      >
                        <div className={cn("absolute inset-0", wp.class)} />
                        {settings.appearance.wallpaper === wp.id && (
                          <div className="absolute inset-0 bg-natural-sage/20 flex items-center justify-center">
                            <Check className="w-4 h-4 text-natural-sage" />
                          </div>
                        )}
                        <span className="absolute bottom-1 left-0 right-0 text-[8px] font-bold text-center bg-natural-card/80 backdrop-blur-sm py-0.5">{wp.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bubble Style & Font */}
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Bubble Style</label>
                    <div className="flex bg-natural-bg p-1 rounded-xl border border-natural-border">
                      {(['rounded', 'classic'] as const).map((style) => (
                        <button
                          key={style}
                          onClick={() => updateSetting('appearance', 'bubbleStyle', style)}
                          className={cn(
                            "flex-1 flex items-center justify-center py-2 text-[10px] font-black uppercase transition-all rounded-lg",
                            settings.appearance.bubbleStyle === style ? "bg-natural-card text-natural-ink shadow-sm" : "text-natural-ink-light hover:text-natural-ink"
                          )}
                        >
                          {style === 'rounded' ? 'R' : 'C'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Chat Font</label>
                    <div className="flex bg-natural-bg p-1 rounded-xl border border-natural-border">
                      <select 
                        value={settings.appearance.chatFont}
                        onChange={(e) => updateSetting('appearance', 'chatFont', e.target.value)}
                        className="w-full bg-natural-card text-[10px] font-black uppercase outline-none px-2 py-1 border border-natural-border rounded-lg"
                      >
                        {FONTS.map(f => (
                          <option key={f.id} value={f.id}>{f.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Nitro-like Features */}
                <div className="space-y-6 pt-4 border-t border-natural-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Message Glow</label>
                      <p className="text-[10px] text-natural-ink-muted">Add a subtle neon glow to your messages.</p>
                    </div>
                    <button
                      onClick={() => updateSetting('appearance', 'messageGlow', !settings.appearance.messageGlow)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.appearance.messageGlow ? "bg-natural-sage" : "bg-natural-border"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.appearance.messageGlow ? "left-7" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-natural-ink-light uppercase tracking-widest">Custom Message Color</label>
                    <div className="flex flex-wrap gap-3">
                      <button
                        onClick={() => updateSetting('appearance', 'customMessageColor', null)}
                        className={cn(
                          "w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all",
                          settings.appearance.customMessageColor === null ? "border-natural-ink scale-110" : "border-transparent hover:scale-105"
                        )}
                        title="Default"
                      >
                        <div className="w-6 h-6 rounded-full bg-natural-sage" />
                      </button>
                      {['#FF0080', '#7928CA', '#FF4D4D', '#F5A623', '#0070F3', '#00DFD8'].map((color) => (
                        <button
                          key={color}
                          onClick={() => updateSetting('appearance', 'customMessageColor', color)}
                          className={cn(
                            "w-8 h-8 rounded-full border-2 transition-all",
                            settings.appearance.customMessageColor === color ? "border-natural-ink scale-110" : "border-transparent hover:scale-105"
                          )}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && settings && (
              <div className="max-w-md space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-natural-bg rounded-2xl border border-natural-border">
                    <div>
                      <h4 className="font-bold text-natural-ink">Show Online Status</h4>
                      <p className="text-xs text-natural-ink-muted">Allow others to see when you are active.</p>
                    </div>
                    <button 
                      onClick={() => updateSetting('security', 'showOnlineStatus', !settings.security.showOnlineStatus)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.security.showOnlineStatus ? "bg-natural-sage" : "bg-gray-300"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.security.showOnlineStatus ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-natural-bg rounded-2xl border border-natural-border">
                    <div>
                      <h4 className="font-bold text-natural-ink">Allow Friend Requests</h4>
                      <p className="text-xs text-natural-ink-muted">Let others find you by email.</p>
                    </div>
                    <button 
                      onClick={() => updateSetting('security', 'allowFriendRequests', !settings.security.allowFriendRequests)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        settings.security.allowFriendRequests ? "bg-natural-sage" : "bg-gray-300"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                        settings.security.allowFriendRequests ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="pt-8 border-t border-natural-border">
                    <button className="w-full py-3 bg-red-50 text-red-600 rounded-xl text-sm font-bold hover:bg-red-100 transition-all">
                      Delete Account
                    </button>
                    <p className="mt-2 text-[10px] text-center text-natural-ink-muted uppercase tracking-widest">This action is irreversible</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
