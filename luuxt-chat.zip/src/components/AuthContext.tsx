import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, onAuthStateChanged, User, signInWithPopup, googleProvider, signOut, db, doc, setDoc, getDoc, serverTimestamp, onSnapshot } from '../lib/firebase';
import { UserProfile, UserSettings } from '../types';

const DEFAULT_SETTINGS: UserSettings = {
  notifications: {
    sound: true,
    desktop: true,
    mentionsOnly: false,
  },
  appearance: {
    theme: 'light',
    fontSize: 'medium',
    accentColor: '#8C9A8E',
    wallpaper: 'none',
    bubbleStyle: 'rounded',
    chatFont: 'sans',
    messageGlow: false,
    customMessageColor: null,
  },
  security: {
    showOnlineStatus: true,
    allowFriendRequests: true,
  },
};

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signIn: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        
        // Initial sync
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          const initialProfile: UserProfile = {
            uid: currentUser.uid,
            displayName: currentUser.displayName || 'Anonymous',
            photoURL: currentUser.photoURL,
            email: currentUser.email || '',
            lastSeen: serverTimestamp() as any,
            settings: DEFAULT_SETTINGS,
          };
          await setDoc(userRef, initialProfile);
        } else {
          await setDoc(userRef, { lastSeen: serverTimestamp() }, { merge: true });
        }

        // Sync email mapping for invitations
        if (currentUser.email) {
          const emailRef = doc(db, 'user_emails', currentUser.email.toLowerCase());
          await setDoc(emailRef, { uid: currentUser.uid }, { merge: true });
        }

        // Real-time profile listener
        unsubscribeProfile = onSnapshot(userRef, (doc) => {
          if (doc.exists()) {
            setProfile({ uid: doc.id, ...doc.data() } as UserProfile);
          }
        });
      } else {
        if (unsubscribeProfile) unsubscribeProfile();
        setProfile(null);
      }
      
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const signIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Sign in error:', error);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signIn, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
