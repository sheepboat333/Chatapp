import React, { useState, useEffect } from 'react';
import { db, collection, query, where, onSnapshot, addDoc, serverTimestamp, doc, getDoc, deleteDoc, getDocsFromServer } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { UserProfile, Friendship, OperationType } from '../types';
import { handleFirestoreError } from '../lib/firestore-helpers';
import { UserPlus, UserMinus, MessageCircle, Phone, Search, X, Video, Plus } from 'lucide-react';
import { cn } from '../lib/utils';

interface FriendsListProps {
  onStartDM: (friendUid: string) => void;
  onCallFriend: (friendUid: string, type: 'audio' | 'video') => void;
}

export function FriendsList({ onStartDM, onCallFriend }: FriendsListProps) {
  const [friends, setFriends] = useState<UserProfile[]>([]);
  const [searchEmail, setSearchEmail] = useState('');
  const [searchResult, setSearchResult] = useState<UserProfile | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { profile } = useAuth();

  useEffect(() => {
    if (!profile) return;

    // Listen for friendships where the user is a member
    const q = query(
      collection(db, 'friendships'),
      where('uids', 'array-contains', profile.uid)
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const friendUids = snapshot.docs.map(doc => {
        const data = doc.data() as Friendship;
        return data.uids.find(uid => uid !== profile.uid);
      }).filter(Boolean) as string[];

      if (friendUids.length === 0) {
        setFriends([]);
        return;
      }

      // Fetch friend profiles
      const friendProfiles: UserProfile[] = [];
      for (const uid of friendUids) {
        try {
          const userSnap = await getDoc(doc(db, 'users', uid));
          if (userSnap.exists()) {
            friendProfiles.push({ uid: userSnap.id, ...userSnap.data() } as UserProfile);
          }
        } catch (err) {
          console.error('Error fetching friend profile:', err);
        }
      }
      setFriends(friendProfiles);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'friendships');
    });

    return unsubscribe;
  }, [profile]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchEmail.trim() || !profile) return;

    setIsSearching(true);
    setError(null);
    setSearchResult(null);

    try {
      const emailMappingRef = doc(db, 'user_emails', searchEmail.trim().toLowerCase());
      const mappingSnap = await getDoc(emailMappingRef);

      if (!mappingSnap.exists()) {
        setError('User not found. They must log in to Luuxt Chat first.');
        return;
      }

      const targetUid = mappingSnap.data().uid;
      if (targetUid === profile.uid) {
        setError("You can't add yourself as a friend.");
        return;
      }

      const userSnap = await getDoc(doc(db, 'users', targetUid));
      if (userSnap.exists()) {
        setSearchResult({ uid: userSnap.id, ...userSnap.data() } as UserProfile);
      }
    } catch (err) {
      setError('Failed to search user.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddFriend = async (targetUid: string) => {
    if (!profile) return;

    try {
      // Check if already friends
      const q = query(
        collection(db, 'friendships'),
        where('uids', 'array-contains', profile.uid)
      );
      const snap = await getDocsFromServer(q); 
      const alreadyFriends = snap.docs.some(doc => (doc.data() as Friendship).uids.includes(targetUid));

      if (alreadyFriends) {
        setError('You are already friends with this user.');
        return;
      }

      await addDoc(collection(db, 'friendships'), {
        uids: [profile.uid, targetUid],
        createdAt: serverTimestamp()
      });
      setSearchResult(null);
      setSearchEmail('');
    } catch (err) {
      setError('Failed to add friend.');
    }
  };

  const handleRemoveFriend = async (targetUid: string) => {
    if (!profile) return;

    try {
      const q = query(
        collection(db, 'friendships'),
        where('uids', 'array-contains', profile.uid)
      );
      const snap = await getDocsFromServer(q);
      const friendshipDoc = snap.docs.find(doc => (doc.data() as Friendship).uids.includes(targetUid));

      if (friendshipDoc) {
        await deleteDoc(doc(db, 'friendships', friendshipDoc.id));
      }
    } catch (err) {
      setError('Failed to remove friend.');
    }
  };

  return (
    <div className="flex flex-col h-full bg-natural-card rounded-3xl border border-natural-border overflow-hidden shadow-sm">
      <div className="p-8 border-b border-natural-border bg-natural-bg/20">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-black text-natural-ink tracking-tight">Friends</h3>
          <div className="px-2 py-1 bg-natural-sage/10 text-natural-sage text-[10px] font-bold uppercase tracking-widest rounded-md">
            {friends.length} Total
          </div>
        </div>
        
        <form onSubmit={handleSearch} className="relative group">
          <input
            type="email"
            value={searchEmail}
            onChange={(e) => setSearchEmail(e.target.value)}
            placeholder="Add friend by email..."
            className="w-full pl-11 pr-4 py-3 bg-natural-card border border-natural-border rounded-2xl text-sm outline-none focus:border-natural-sage transition-all shadow-sm group-hover:border-natural-ink-light/20"
          />
          <Search className="absolute left-4 top-3.5 w-4 h-4 text-natural-ink-light group-focus-within:text-natural-sage transition-colors" />
          {searchEmail && (
            <button 
              type="button"
              onClick={() => setSearchEmail('')}
              className="absolute right-3 top-3.5 p-0.5 hover:bg-natural-bg rounded-full"
            >
              <X className="w-3 h-3 text-natural-ink-light" />
            </button>
          )}
        </form>

        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-100 text-red-600 text-[11px] font-bold uppercase tracking-wider rounded-xl flex items-center justify-between animate-in slide-in-from-top-2">
            <span>{error}</span>
            <button onClick={() => setError(null)} className="p-1 hover:bg-red-100 rounded-full"><X className="w-3 h-3" /></button>
          </div>
        )}

        {searchResult && (
          <div className="mt-6 p-4 bg-natural-card border-2 border-natural-sage/20 rounded-2xl flex items-center justify-between animate-in zoom-in-95 duration-200 shadow-lg shadow-natural-sage/5">
            <div className="flex items-center gap-4">
              <div className="relative">
                <img 
                  src={searchResult.photoURL || `https://ui-avatars.com/api/?name=${searchResult.displayName}`} 
                  className="w-12 h-12 rounded-2xl border border-natural-border" 
                  referrerPolicy="no-referrer" 
                />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-natural-sage rounded-full border-2 border-white flex items-center justify-center">
                  <Plus className="w-2 h-2 text-white" />
                </div>
              </div>
              <div>
                <p className="font-bold text-natural-ink">{searchResult.displayName}</p>
                <p className="text-xs text-natural-ink-light truncate max-w-[140px]">{searchResult.email}</p>
              </div>
            </div>
            <button
              onClick={() => handleAddFriend(searchResult.uid)}
              className="px-4 py-2 bg-natural-sage text-white rounded-xl text-xs font-bold hover:opacity-90 transition-all shadow-md shadow-natural-sage/20"
            >
              Add Friend
            </button>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-3">
        {friends.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8">
            <div className="w-20 h-20 bg-natural-bg rounded-3xl flex items-center justify-center mb-6 border border-natural-border transform rotate-6">
              <UserPlus className="w-10 h-10 text-natural-ink-light opacity-30" />
            </div>
            <h4 className="text-lg font-bold text-natural-ink mb-2">Start your network</h4>
            <p className="text-sm text-natural-ink-muted max-w-[200px] mx-auto">Add friends by email to start private chats and calls.</p>
          </div>
        ) : (
          friends.map(friend => (
            <div key={friend.uid} className="group p-4 hover:bg-natural-bg rounded-2xl transition-all flex items-center justify-between border border-transparent hover:border-natural-border">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img 
                    src={friend.photoURL || `https://ui-avatars.com/api/?name=${friend.displayName}`} 
                    className="w-12 h-12 rounded-2xl border border-natural-border bg-white" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                </div>
                <div>
                  <p className="text-sm font-bold text-natural-ink">{friend.displayName}</p>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                    <span className="text-[10px] font-bold text-natural-ink-light uppercase tracking-widest">Online</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                <button
                  onClick={() => onStartDM(friend.uid)}
                  className="p-2.5 text-natural-ink-light hover:text-natural-sage hover:bg-white rounded-xl transition-all shadow-sm border border-transparent hover:border-natural-border"
                  title="Message"
                >
                  <MessageCircle className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onCallFriend(friend.uid, 'audio')}
                  className="p-2.5 text-natural-ink-light hover:text-natural-sage hover:bg-white rounded-xl transition-all shadow-sm border border-transparent hover:border-natural-border"
                  title="Audio Call"
                >
                  <Phone className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onCallFriend(friend.uid, 'video')}
                  className="p-2.5 text-natural-ink-light hover:text-natural-sage hover:bg-white rounded-xl transition-all shadow-sm border border-transparent hover:border-natural-border"
                  title="Video Call"
                >
                  <Video className="w-4 h-4" />
                </button>
                <div className="w-px h-4 bg-natural-border mx-1"></div>
                <button
                  onClick={() => handleRemoveFriend(friend.uid)}
                  className="p-2.5 text-natural-ink-light hover:text-red-500 hover:bg-red-50 rounded-xl transition-all shadow-sm border border-transparent hover:border-red-100"
                  title="Remove Friend"
                >
                  <UserMinus className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
