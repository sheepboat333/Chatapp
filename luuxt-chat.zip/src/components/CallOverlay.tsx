import React, { useState, useEffect, useRef } from 'react';
import { db, collection, doc, setDoc, getDoc, updateDoc, onSnapshot, deleteDoc, addDoc } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { Call, OperationType } from '../types';
import { handleFirestoreError } from '../lib/firestore-helpers';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Maximize2, Minimize2, Monitor, MonitorOff, Phone } from 'lucide-react';
import { cn } from '../lib/utils';

interface CallOverlayProps {
  callId: string;
  onEnd: () => void;
}

export function CallOverlay({ callId, onEnd }: CallOverlayProps) {
  const [call, setCall] = useState<Call | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const { profile } = useAuth();

  const servers = {
    iceServers: [
      { urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] },
    ],
    iceCandidatePoolSize: 10,
  };

  useEffect(() => {
    if (!profile) return;

    const unsubscribe = onSnapshot(doc(db, 'calls', callId), async (snapshot) => {
      const data = snapshot.data() as Call;
      if (!data) return;
      setCall(data);

      if (data.status === 'ended' || data.status === 'rejected') {
        cleanup();
        onEnd();
        return;
      }

      if (data.callerUid === profile.uid && data.status === 'active' && data.answer && !pcRef.current?.remoteDescription) {
        const answerDescription = new RTCSessionDescription(data.answer);
        await pcRef.current?.setRemoteDescription(answerDescription);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `calls/${callId}`);
    });

    return () => {
      unsubscribe();
      cleanup();
    };
  }, [callId, profile]);

  const cleanup = () => {
    localStream?.getTracks().forEach(track => track.stop());
    screenStream?.getTracks().forEach(track => track.stop());
    pcRef.current?.close();
    pcRef.current = null;
  };

  const startCall = async (isCaller: boolean, callType: 'audio' | 'video') => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: callType === 'video', 
        audio: true 
      });
      setLocalStream(stream);
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      if (callType === 'audio') setIsVideoOff(true);

      const pc = new RTCPeerConnection(servers);
      pcRef.current = pc;

      stream.getTracks().forEach(track => pc.addTrack(track, stream));

      pc.ontrack = (event) => {
        setRemoteStream(event.streams[0]);
        if (remoteVideoRef.current) remoteVideoRef.current.srcObject = event.streams[0];
      };

      const callDoc = doc(db, 'calls', callId);
      const offerCandidates = collection(callDoc, 'offerCandidates');
      const answerCandidates = collection(callDoc, 'answerCandidates');

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          addDoc(isCaller ? offerCandidates : answerCandidates, event.candidate.toJSON());
        }
      };

      if (isCaller) {
        const offerDescription = await pc.createOffer();
        await pc.setLocalDescription(offerDescription);
        await updateDoc(callDoc, { offer: { type: offerDescription.type, sdp: offerDescription.sdp } });

        onSnapshot(answerCandidates, (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const candidate = new RTCIceCandidate(change.doc.data());
              pc.addIceCandidate(candidate);
            }
          });
        });
      } else {
        const callData = (await getDoc(callDoc)).data() as Call;
        const offerDescription = new RTCSessionDescription(callData.offer);
        await pc.setRemoteDescription(offerDescription);

        const answerDescription = await pc.createAnswer();
        await pc.setLocalDescription(answerDescription);
        await updateDoc(callDoc, { 
          answer: { type: answerDescription.type, sdp: answerDescription.sdp },
          status: 'active'
        });

        onSnapshot(offerCandidates, (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const candidate = new RTCIceCandidate(change.doc.data());
              pc.addIceCandidate(candidate);
            }
          });
        });
      }
    } catch (err) {
      console.error("Error starting call:", err);
    }
  };

  useEffect(() => {
    if (call && profile) {
      const isCaller = call.callerUid === profile.uid;
      if (isCaller && !pcRef.current) {
        startCall(true, call.type);
      } else if (!isCaller && call.status === 'ringing' && !pcRef.current) {
        startCall(false, call.type);
      }
    }
  }, [call, profile]);

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks()[0].enabled = isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks()[0].enabled = isVideoOff;
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        setScreenStream(stream);
        setIsScreenSharing(true);
        
        const videoTrack = stream.getVideoTracks()[0];
        if (pcRef.current) {
          const sender = pcRef.current.getSenders().find(s => s.track?.kind === 'video');
          if (sender) sender.replaceTrack(videoTrack);
        }

        videoTrack.onended = () => {
          stopScreenShare();
        };
      } catch (err) {
        console.error("Error starting screen share:", err);
      }
    } else {
      stopScreenShare();
    }
  };

  const stopScreenShare = () => {
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
      setScreenStream(null);
    }
    setIsScreenSharing(false);
    
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (pcRef.current) {
        const sender = pcRef.current.getSenders().find(s => s.track?.kind === 'video');
        if (sender) sender.replaceTrack(videoTrack);
      }
    }
  };

  const handleEndCall = async () => {
    await updateDoc(doc(db, 'calls', callId), { status: 'ended' });
    onEnd();
  };

  if (!call) return null;

  return (
    <div className={cn(
      "fixed z-[100] transition-all duration-500 ease-in-out bg-natural-card shadow-2xl overflow-hidden",
      isMinimized 
        ? "bottom-6 right-6 w-80 h-52 rounded-3xl border-2 border-natural-sage shadow-2xl" 
        : "inset-0 flex flex-col"
    )}>
      <div className="relative flex-1 bg-black/95 flex items-center justify-center">
        {call.type === 'video' ? (
          remoteStream ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex flex-col items-center gap-6">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-natural-sage/20 animate-ping absolute inset-0" />
                <div className="w-24 h-24 rounded-full bg-natural-sage flex items-center justify-center relative z-10 shadow-xl">
                  <Video className="w-10 h-10 text-white" />
                </div>
              </div>
              <div className="text-center">
                <p className="text-white font-bold text-xl mb-1">
                  {call.status === 'ringing' ? 'Calling...' : 'Connecting...'}
                </p>
                <p className="text-white/40 text-sm uppercase tracking-widest font-bold">Please wait</p>
              </div>
            </div>
          )
        ) : (
          <div className="flex flex-col items-center gap-8">
            <div className="relative">
              <div className="w-40 h-40 rounded-full bg-natural-sage/10 animate-ping absolute inset-0" />
              <div className="w-40 h-40 rounded-full bg-natural-sage/20 animate-pulse absolute inset-0 scale-110" />
              <div className="w-40 h-40 rounded-full bg-natural-sage flex items-center justify-center relative z-10 shadow-2xl border-8 border-white/5">
                <Phone className="w-16 h-16 text-white" />
              </div>
            </div>
            <div className="text-center">
              <h3 className="text-3xl font-black text-white mb-3 tracking-tight">Voice Call</h3>
              <div className="flex items-center justify-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <p className="text-white/60 font-medium uppercase tracking-widest text-xs">
                  {call.status === 'ringing' ? 'Ringing...' : 'Encrypted Connection'}
                </p>
              </div>
            </div>
          </div>
        )}

        {call.type === 'video' && (
          <div className={cn(
            "absolute transition-all duration-500",
            isMinimized ? "top-3 right-3 w-24 h-16" : "bottom-32 right-10 w-64 h-40",
            "rounded-2xl border-2 border-white/10 overflow-hidden bg-natural-ink shadow-2xl"
          )}>
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
            {(isVideoOff && !isScreenSharing) && (
              <div className="absolute inset-0 bg-natural-ink flex items-center justify-center">
                <VideoOff className="w-8 h-8 text-white/20" />
              </div>
            )}
          </div>
        )}

        {!isMinimized && (
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-5 px-10 py-5 bg-natural-card/40 backdrop-blur-xl rounded-full border border-white/10 shadow-2xl">
            <button
              onClick={toggleMute}
              className={cn(
                "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                isMuted ? "bg-red-500 text-white shadow-lg shadow-red-500/20" : "bg-white/10 text-white hover:bg-white/20"
              )}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>
            {call.type === 'video' && (
              <>
                <button
                  onClick={toggleVideo}
                  className={cn(
                    "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                    isVideoOff ? "bg-red-500 text-white shadow-lg shadow-red-500/20" : "bg-white/10 text-white hover:bg-white/20"
                  )}
                >
                  {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
                </button>
                <button
                  onClick={toggleScreenShare}
                  className={cn(
                    "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                    isScreenSharing ? "bg-natural-sage text-white shadow-lg shadow-natural-sage/20" : "bg-white/10 text-white hover:bg-white/20"
                  )}
                >
                  {isScreenSharing ? <MonitorOff className="w-6 h-6" /> : <Monitor className="w-6 h-6" />}
                </button>
              </>
            )}
            <button
              onClick={handleEndCall}
              className="p-4 bg-red-600 text-white rounded-2xl hover:bg-red-700 transition-all transform hover:scale-110 active:scale-95 shadow-xl shadow-red-600/30"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
            <div className="w-px h-10 bg-white/10 mx-2" />
            <button
              onClick={() => setIsMinimized(true)}
              className="p-4 bg-white/5 text-white rounded-2xl hover:bg-white/10 transition-all transform hover:scale-110 active:scale-95"
            >
              <Minimize2 className="w-6 h-6" />
            </button>
          </div>
        )}

        {isMinimized && (
          <div className="absolute top-3 left-3 flex gap-2">
            <button
              onClick={() => setIsMinimized(false)}
              className="p-2 bg-black/60 text-white rounded-xl hover:bg-black/80 transition-all backdrop-blur-md border border-white/10"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
