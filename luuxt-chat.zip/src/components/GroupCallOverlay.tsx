import React, { useState, useEffect, useRef } from 'react';
import { db, collection, doc, setDoc, getDoc, updateDoc, onSnapshot, deleteDoc, addDoc, query, where } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { RoomCall, OperationType, UserProfile } from '../types';
import { handleFirestoreError } from '../lib/firestore-helpers';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Maximize2, Minimize2, Monitor, MonitorOff, Users } from 'lucide-react';
import { cn } from '../lib/utils';

interface GroupCallOverlayProps {
  roomCallId: string;
  onEnd: () => void;
}

interface PeerConnection {
  uid: string;
  pc: RTCPeerConnection;
  stream: MediaStream | null;
  profile?: UserProfile;
}

export function GroupCallOverlay({ roomCallId, onEnd }: GroupCallOverlayProps) {
  const [roomCall, setRoomCall] = useState<RoomCall | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [peers, setPeers] = useState<PeerConnection[]>([]);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  
  const hasInitializedStream = useRef(false);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const pcsRef = useRef<{ [uid: string]: RTCPeerConnection }>({});
  const { profile } = useAuth();

  const servers = {
    iceServers: [
      { urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] },
    ],
    iceCandidatePoolSize: 10,
  };

  useEffect(() => {
    if (!profile) return;

    const setupLocalStream = async (callType: 'audio' | 'video') => {
      if (hasInitializedStream.current) return;
      hasInitializedStream.current = true;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: callType === 'video', 
          audio: true 
        });
        setLocalStream(stream);
        if (localVideoRef.current) localVideoRef.current.srcObject = stream;
        if (callType === 'audio') setIsVideoOff(true);
        
        // Join participants
        await setDoc(doc(db, 'room_calls', roomCallId, 'participants', profile.uid), {
          uid: profile.uid,
          joinedAt: new Date(),
          isVideoOff: callType === 'audio',
          isMuted: false
        });
      } catch (err) {
        console.error("Error accessing media devices:", err);
      }
    };

    const unsubscribeCall = onSnapshot(doc(db, 'room_calls', roomCallId), (snapshot) => {
      const data = snapshot.data() as RoomCall;
      if (!data || !data.active) {
        cleanup();
        onEnd();
        return;
      }
      setRoomCall(data);
      if (!hasInitializedStream.current) {
        setupLocalStream(data.type);
      }
    });

    // Listen for other participants
    const unsubscribeParticipants = onSnapshot(collection(db, 'room_calls', roomCallId, 'participants'), (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        const participantData = change.doc.data();
        const otherUid = participantData.uid;

        if (otherUid === profile.uid) return;

        if (change.type === 'added') {
          initiatePeerConnection(otherUid);
        } else if (change.type === 'removed') {
          removePeerConnection(otherUid);
        }
      });
    });

    return () => {
      unsubscribeCall();
      unsubscribeParticipants();
      cleanup();
    };
  }, [roomCallId, profile]);

  const cleanup = () => {
    localStream?.getTracks().forEach(track => track.stop());
    screenStream?.getTracks().forEach(track => track.stop());
    Object.values(pcsRef.current).forEach((pc: any) => pc.close());
    pcsRef.current = {};
    if (profile) {
      deleteDoc(doc(db, 'room_calls', roomCallId, 'participants', profile.uid)).catch(() => {});
    }
  };

  const initiatePeerConnection = async (otherUid: string) => {
    if (!profile || pcsRef.current[otherUid]) return;

    const pc = new RTCPeerConnection(servers);
    pcsRef.current[otherUid] = pc;

    if (localStream) {
      localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    }

    pc.ontrack = (event) => {
      setPeers(prev => {
        const existing = prev.find(p => p.uid === otherUid);
        if (existing) {
          return prev.map(p => p.uid === otherUid ? { ...p, stream: event.streams[0] } : p);
        }
        return [...prev, { uid: otherUid, pc, stream: event.streams[0] }];
      });
    };

    // Signaling
    const isCaller = profile.uid < otherUid;
    const signalId = isCaller ? `${profile.uid}_${otherUid}` : `${otherUid}_${profile.uid}`;
    const signalDoc = doc(db, 'room_calls', roomCallId, 'signaling', signalId);

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        const candidateCollection = collection(signalDoc, isCaller ? 'callerCandidates' : 'receiverCandidates');
        addDoc(candidateCollection, event.candidate.toJSON());
      }
    };

    if (isCaller) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await setDoc(signalDoc, { offer: { type: offer.type, sdp: offer.sdp }, callerUid: profile.uid }, { merge: true });

      onSnapshot(signalDoc, async (snap) => {
        const data = snap.data();
        if (data?.answer && !pc.remoteDescription) {
          await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
        }
      });

      onSnapshot(collection(signalDoc, 'receiverCandidates'), (snap) => {
        snap.docChanges().forEach(change => {
          if (change.type === 'added') {
            pc.addIceCandidate(new RTCIceCandidate(change.doc.data()));
          }
        });
      });
    } else {
      onSnapshot(signalDoc, async (snap) => {
        const data = snap.data();
        if (data?.offer && !pc.remoteDescription) {
          await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await updateDoc(signalDoc, { answer: { type: answer.type, sdp: answer.sdp } });
        }
      });

      onSnapshot(collection(signalDoc, 'callerCandidates'), (snap) => {
        snap.docChanges().forEach(change => {
          if (change.type === 'added') {
            pc.addIceCandidate(new RTCIceCandidate(change.doc.data()));
          }
        });
      });
    }

    // Fetch profile for the peer
    const userSnap = await getDoc(doc(db, 'users', otherUid));
    if (userSnap.exists()) {
      setPeers(prev => prev.map(p => p.uid === otherUid ? { ...p, profile: userSnap.data() as UserProfile } : p));
    }
  };

  const removePeerConnection = (uid: string) => {
    if (pcsRef.current[uid]) {
      pcsRef.current[uid].close();
      delete pcsRef.current[uid];
    }
    setPeers(prev => prev.filter(p => p.uid !== uid));
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks()[0].enabled = isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks()[0].enabled = isVideoOff;
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        setScreenStream(stream);
        setIsScreenSharing(true);
        
        const videoTrack = stream.getVideoTracks()[0];
        Object.values(pcsRef.current).forEach((pc: any) => {
          const sender = pc.getSenders().find((s: any) => s.track?.kind === 'video');
          if (sender) sender.replaceTrack(videoTrack);
        });

        videoTrack.onended = () => stopScreenShare();
      } catch (err) {
        console.error("Error starting screen share:", err);
      }
    } else {
      stopScreenShare();
    }
  };

  const stopScreenShare = () => {
    if (screenStream) {
      screenStream.getTracks().forEach(track => track.stop());
      setScreenStream(null);
    }
    setIsScreenSharing(false);
    
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      Object.values(pcsRef.current).forEach((pc: any) => {
        const sender = pc.getSenders().find((s: any) => s.track?.kind === 'video');
        if (sender) sender.replaceTrack(videoTrack);
      });
    }
  };

  const handleEndCall = async () => {
    if (roomCall?.startedBy === profile?.uid) {
      await updateDoc(doc(db, 'room_calls', roomCallId), { active: false });
    }
    cleanup();
    onEnd();
  };

  return (
    <div className={cn(
      "fixed z-[100] transition-all duration-500 ease-in-out bg-natural-card shadow-2xl overflow-hidden",
      isMinimized 
        ? "bottom-6 right-6 w-80 h-52 rounded-3xl border-2 border-natural-sage shadow-2xl" 
        : "inset-0 flex flex-col"
    )}>
      <div className="relative flex-1 bg-black/95 p-6">
        {/* Video Grid */}
        <div className={cn(
          "grid gap-6 h-full",
          peers.length === 0 ? "grid-cols-1" : 
          peers.length === 1 ? "grid-cols-2" : 
          peers.length <= 3 ? "grid-cols-2 grid-rows-2" : "grid-cols-3 grid-rows-2"
        )}>
          {/* Local Video */}
          <div className="relative rounded-3xl overflow-hidden bg-natural-ink border border-white/10 shadow-xl">
            {roomCall?.type === 'video' ? (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-0 bg-natural-ink flex flex-col items-center justify-center gap-6">
                <div className="relative">
                  <div className="w-28 h-28 rounded-full bg-natural-sage/10 animate-pulse absolute inset-0 scale-110" />
                  <img 
                    src={profile?.photoURL || `https://ui-avatars.com/api/?name=${profile?.displayName}`} 
                    className="w-28 h-28 rounded-full border-4 border-natural-sage shadow-2xl relative z-10"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-white font-black text-xl tracking-tight">{profile?.displayName}</div>
              </div>
            )}
            <div className="absolute bottom-4 left-4 px-4 py-2 bg-black/40 backdrop-blur-xl rounded-xl text-white text-xs font-bold border border-white/10">
              You {isMuted && "• Muted"}
            </div>
            {isVideoOff && !isScreenSharing && roomCall?.type === 'video' && (
              <div className="absolute inset-0 bg-natural-ink flex items-center justify-center">
                <VideoOff className="w-12 h-12 text-white/10" />
              </div>
            )}
          </div>

          {/* Peer Videos */}
          {peers.map(peer => (
            <div key={peer.uid} className="relative rounded-3xl overflow-hidden bg-natural-ink border border-white/10 shadow-xl">
              {roomCall?.type === 'video' ? (
                peer.stream ? (
                  <video
                    autoPlay
                    playsInline
                    ref={el => { if (el) el.srcObject = peer.stream; }}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <div className="relative">
                      <div className="w-20 h-20 rounded-full bg-natural-sage/20 animate-ping absolute inset-0" />
                      <div className="w-20 h-20 rounded-full bg-natural-sage flex items-center justify-center relative z-10">
                        <Users className="w-10 h-10 text-white" />
                      </div>
                    </div>
                    <p className="text-white/40 text-xs font-bold uppercase tracking-widest">Connecting...</p>
                  </div>
                )
              ) : (
                <div className="absolute inset-0 bg-natural-ink flex flex-col items-center justify-center gap-6">
                  <div className="relative">
                    <div className="w-28 h-28 rounded-full bg-natural-sage/10 animate-pulse absolute inset-0 scale-110" />
                    <img 
                      src={peer.profile?.photoURL || `https://ui-avatars.com/api/?name=${peer.profile?.displayName}`} 
                      className="w-28 h-28 rounded-full border-4 border-natural-sage/30 shadow-2xl relative z-10"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="text-white font-black text-xl tracking-tight">{peer.profile?.displayName || 'Participant'}</div>
                </div>
              )}
              <div className="absolute bottom-4 left-4 px-4 py-2 bg-black/40 backdrop-blur-xl rounded-xl text-white text-xs font-bold border border-white/10">
                {peer.profile?.displayName || 'Participant'}
              </div>
            </div>
          ))}
        </div>

        {/* Controls Overlay */}
        {!isMinimized && (
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-5 px-10 py-5 bg-natural-card/40 backdrop-blur-xl rounded-full border border-white/10 shadow-2xl">
            <button
              onClick={toggleMute}
              className={cn(
                "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                isMuted ? "bg-red-500 text-white shadow-lg shadow-red-500/20" : "bg-white/10 text-white hover:bg-white/20"
              )}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>
            {roomCall?.type === 'video' && (
              <>
                <button
                  onClick={toggleVideo}
                  className={cn(
                    "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                    isVideoOff ? "bg-red-500 text-white shadow-lg shadow-red-500/20" : "bg-white/10 text-white hover:bg-white/20"
                  )}
                >
                  {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
                </button>
                <button
                  onClick={toggleScreenShare}
                  className={cn(
                    "p-4 rounded-2xl transition-all transform hover:scale-110 active:scale-95",
                    isScreenSharing ? "bg-natural-sage text-white shadow-lg shadow-natural-sage/20" : "bg-white/10 text-white hover:bg-white/20"
                  )}
                >
                  {isScreenSharing ? <MonitorOff className="w-6 h-6" /> : <Monitor className="w-6 h-6" />}
                </button>
              </>
            )}
            <button
              onClick={handleEndCall}
              className="p-4 bg-red-600 text-white rounded-2xl hover:bg-red-700 transition-all transform hover:scale-110 active:scale-95 shadow-xl shadow-red-600/30"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
            <div className="w-px h-10 bg-white/10 mx-2" />
            <button
              onClick={() => setIsMinimized(true)}
              className="p-4 bg-white/5 text-white rounded-2xl hover:bg-white/10 transition-all transform hover:scale-110 active:scale-95"
            >
              <Minimize2 className="w-6 h-6" />
            </button>
          </div>
        )}

        {isMinimized && (
          <div className="absolute top-3 left-3 flex gap-2">
            <button
              onClick={() => setIsMinimized(false)}
              className="p-2 bg-black/60 text-white rounded-xl hover:bg-black/80 transition-all backdrop-blur-md border border-white/10"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
