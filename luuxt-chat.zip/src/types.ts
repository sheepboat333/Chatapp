import { Timestamp } from 'firebase/firestore';

export interface UserSettings {
  notifications: {
    sound: boolean;
    desktop: boolean;
    mentionsOnly: boolean;
  };
  appearance: {
    theme: 'light' | 'dark' | 'system';
    fontSize: 'small' | 'medium' | 'large';
    accentColor: string;
    wallpaper: string;
    bubbleStyle: 'rounded' | 'classic';
    chatFont: 'sans' | 'mono' | 'serif' | 'modern' | 'playful';
    messageGlow: boolean;
    customMessageColor: string | null;
  };
  security: {
    showOnlineStatus: boolean;
    allowFriendRequests: boolean;
  };
}

export interface UserProfile {
  uid: string;
  displayName: string;
  photoURL: string | null;
  email: string;
  lastSeen?: Timestamp;
  settings?: UserSettings;
}

export interface Room {
  id: string;
  name: string;
  description?: string;
  createdBy: string;
  createdAt: Timestamp;
  members: string[];
  type: 'channel' | 'dm';
  typing?: { [uid: string]: { isTyping: boolean, displayName: string } };
}

export interface Friendship {
  id: string;
  uids: string[];
  createdAt: Timestamp;
}

export interface Call {
  id: string;
  callerUid: string;
  receiverUid: string;
  offer?: any;
  answer?: any;
  status: 'ringing' | 'active' | 'ended' | 'rejected';
  type: 'audio' | 'video';
  createdAt: Timestamp;
}

export interface RoomCall {
  id: string;
  roomId: string;
  active: boolean;
  startedBy: string;
  type: 'audio' | 'video';
  createdAt: Timestamp;
}

export interface Notification {
  id: string;
  recipientUid: string;
  type: 'message' | 'call';
  title: string;
  body: string;
  data?: any;
  read: boolean;
  createdAt: Timestamp;
}

export interface Message {
  id: string;
  text: string;
  senderUid: string;
  senderName: string;
  senderPhoto: string | null;
  createdAt: Timestamp;
  roomId: string;
  font?: 'sans' | 'mono' | 'serif' | 'modern' | 'playful';
  glow?: boolean;
  color?: string;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}
